
import React from 'react';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({ value, onChange }) => {
  return (
    <div className="mb-8 max-w-xl mx-auto">
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search wallpapers by author..."
        className="w-full px-5 py-3 bg-dark-card border-2 border-slate-700 rounded-full focus:outline-none focus:ring-2 focus:ring-brand-secondary focus:border-transparent transition-all"
      />
    </div>
  );
};
