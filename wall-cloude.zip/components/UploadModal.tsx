
import React, { useState, useCallback } from 'react';
import { Icon } from './Icon';

interface UploadModalProps {
  onClose: () => void;
  onUpload: (file: File, author: string) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({ onClose, onUpload }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [author, setAuthor] = useState('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (file) {
      onUpload(file, author);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
      <div className="bg-dark-card rounded-lg shadow-2xl p-6 md:p-8 w-full max-w-md relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-dark-subtle hover:text-white transition">
          <Icon name="close" className="h-6 w-6" />
        </button>
        <h2 className="text-2xl font-bold mb-4 text-white">Upload Wallpaper</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="author" className="block text-sm font-medium text-dark-subtle mb-1">Author Name (Optional)</label>
            <input
              type="text"
              id="author"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="file-upload" className="block text-sm font-medium text-dark-subtle mb-1">Image</label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-700 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                {preview ? (
                  <img src={preview} alt="Preview" className="mx-auto h-32 w-auto rounded-md object-contain" />
                ) : (
                  <Icon name="image" className="mx-auto h-12 w-12 text-dark-subtle" />
                )}
                <div className="flex text-sm text-gray-600">
                  <label htmlFor="file-upload" className="relative cursor-pointer bg-dark-card rounded-md font-medium text-brand-secondary hover:text-blue-400 focus-within:outline-none">
                    <span>Upload a file</span>
                    <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" onChange={handleFileChange} />
                  </label>
                  <p className="pl-1 text-dark-subtle">or drag and drop</p>
                </div>
                <p className="text-xs text-dark-subtle">PNG, JPG, GIF up to 10MB</p>
              </div>
            </div>
          </div>
          <button
            type="submit"
            disabled={!file}
            className="w-full bg-brand-primary hover:bg-brand-secondary text-white font-bold py-2 px-4 rounded-md transition disabled:bg-slate-600 disabled:cursor-not-allowed"
          >
            Upload
          </button>
        </form>
      </div>
    </div>
  );
};
