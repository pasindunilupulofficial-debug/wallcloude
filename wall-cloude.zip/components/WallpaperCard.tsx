
import React, { useState } from 'react';
import { Wallpaper } from '../types';
import { Icon } from './Icon';

interface WallpaperCardProps {
  wallpaper: Wallpaper;
  onLike: (id: string) => void;
}

export const WallpaperCard: React.FC<WallpaperCardProps> = ({ wallpaper, onLike }) => {
    const [isLiked, setIsLiked] = useState(false);

    const handleDownload = async (url: string) => {
        try {
            const response = await fetch(url);
            const blob = await response.blob();
            const objectUrl = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = objectUrl;
            link.download = `wallcloude-${wallpaper.id}.jpg`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(objectUrl);
        } catch (error) {
            console.error('Error downloading image:', error);
            window.open(url, '_blank');
        }
    };
    
    const handleShare = async (url: string) => {
        const shareData = {
            title: 'Wall Cloude Wallpaper',
            text: 'Check out this awesome wallpaper!',
            url: url,
        };
        try {
            if (navigator.share) {
                await navigator.share(shareData);
            } else {
                await navigator.clipboard.writeText(url);
                alert('Link copied to clipboard!');
            }
        } catch (error) {
            console.error('Error sharing:', error);
            await navigator.clipboard.writeText(url);
            alert('Link copied to clipboard!');
        }
    };

    const handleLikeClick = () => {
        if (!isLiked) {
            onLike(wallpaper.id);
            setIsLiked(true);
        }
    };

    return (
        <div className="group relative overflow-hidden rounded-lg break-inside-avoid shadow-lg transform hover:scale-105 transition-transform duration-300">
            <img src={wallpaper.url} alt={`Wallpaper by ${wallpaper.author}`} className="w-full h-auto object-cover" />
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all duration-300 flex flex-col justify-between p-4">
                <div className="flex justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-300 space-x-2">
                    <button onClick={handleLikeClick} className={`p-2 rounded-full transition-colors ${isLiked ? 'bg-red-500 text-white' : 'bg-white/20 hover:bg-white/40 text-white'}`}>
                        <Icon name="heart" className="h-5 w-5" />
                    </button>
                    <button onClick={() => handleShare(wallpaper.url)} className="p-2 rounded-full bg-white/20 hover:bg-white/40 text-white transition-colors">
                        <Icon name="share" className="h-5 w-5" />
                    </button>
                    <button onClick={() => handleDownload(wallpaper.url)} className="p-2 rounded-full bg-white/20 hover:bg-white/40 text-white transition-colors">
                        <Icon name="download" className="h-5 w-5" />
                    </button>
                </div>
                <div className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform translate-y-4 group-hover:translate-y-0">
                    <p className="font-bold text-sm truncate">{wallpaper.author}</p>
                    <p className="text-xs text-gray-300">{isLiked ? wallpaper.likes + 1 : wallpaper.likes} likes</p>
                </div>
            </div>
        </div>
    );
};
