
import React from 'react';

interface IconProps {
  name: string;
  className?: string;
}

export const Icon: React.FC<IconProps> = ({ name, className = 'h-6 w-6' }) => {
  const icons: { [key: string]: JSX.Element } = {
    upload: <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />,
    download: <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />,
    heart: <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />,
    share: <path strokeLinecap="round" strokeLinejoin="round"d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.195.025.39.044.583.058a2.25 2.25 0 011.838 1.838c.014.193.033.388.058.583a2.25 2.25 0 002.186 0c.025-.195.044-.39.058-.583a2.25 2.25 0 011.838-1.838c.193-.014.388-.033.583-.058a2.25 2.25 0 000-2.186c-.195-.025-.39-.044-.583-.058a2.25 2.25 0 01-1.838-1.838c-.014-.193-.033-.388-.058-.583a2.25 2.25 0 00-2.186 0c-.025.195-.044.39-.058.583a2.25 2.25 0 01-1.838 1.838c-.193.014-.388.033-.583.058z" />,
    close: <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />,
    sparkles: <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18l-1.807-2.096a4.5 4.5 0 01-1.242-3.043V9a4.5 4.5 0 019 0v1.861a4.5 4.5 0 01-1.242 3.043L15 18l-.813-2.096a4.5 4.5 0 01-4.374 0zM12 21a9 9 0 100-18 9 9 0 000 18z" />,
    image: <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
  };

  return (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      {icons[name] || <circle cx="12" cy="12" r="10" />}
    </svg>
  );
};
