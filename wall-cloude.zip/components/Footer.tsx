
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-dark-card mt-12 py-6">
      <div className="container mx-auto px-4 text-center text-dark-subtle">
        <p>&copy; {new Date().getFullYear()} Wall Cloude. All rights reserved.</p>
        <p>Developed by <a href="#" className="text-brand-secondary hover:underline">Pasindu Nilupul</a></p>
      </div>
    </footer>
  );
};
