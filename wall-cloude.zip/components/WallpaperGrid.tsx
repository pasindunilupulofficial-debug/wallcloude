
import React from 'react';
import { WallpaperCard } from './WallpaperCard';
import { Wallpaper } from '../types';

interface WallpaperGridProps {
  wallpapers: Wallpaper[];
  onLike: (id: string) => void;
}

export const WallpaperGrid: React.FC<WallpaperGridProps> = ({ wallpapers, onLike }) => {
  return (
    <div className="columns-2 sm:columns-3 md:columns-4 lg:columns-5 gap-4 space-y-4">
      {wallpapers.map((wallpaper) => (
        <WallpaperCard
          key={wallpaper.id}
          wallpaper={wallpaper}
          onLike={onLike}
        />
      ))}
    </div>
  );
};
