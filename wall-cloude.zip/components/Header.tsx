
import React from 'react';
import { Icon } from './Icon';

interface HeaderProps {
  onUploadClick: () => void;
  onGenerateClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onUploadClick, onGenerateClick }) => {
  return (
    <header className="bg-dark-card/50 backdrop-blur-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="text-2xl font-bold text-white tracking-wider">
          Wall <span className="text-brand-secondary">Cloude</span>
        </div>
        <div className="flex items-center space-x-2 md:space-x-4">
          <button
            onClick={onGenerateClick}
            className="flex items-center space-x-2 bg-brand-primary hover:bg-brand-secondary text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-300 transform hover:scale-105"
          >
            <Icon name="sparkles" className="h-5 w-5"/>
            <span className="hidden sm:inline">Generate</span>
          </button>
          <button
            onClick={onUploadClick}
            className="flex items-center space-x-2 bg-slate-600 hover:bg-slate-500 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-300 transform hover:scale-105"
          >
            <Icon name="upload" className="h-5 w-5"/>
            <span className="hidden sm:inline">Upload</span>
          </button>
        </div>
      </div>
    </header>
  );
};
