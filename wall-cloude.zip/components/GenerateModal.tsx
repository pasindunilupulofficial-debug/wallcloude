
import React, { useState } from 'react';
import { Icon } from './Icon';
import { Spinner } from './Spinner';

interface GenerateModalProps {
  onClose: () => void;
  onGenerate: (prompt: string) => Promise<void>;
  isGenerating: boolean;
  error: string | null;
}

export const GenerateModal: React.FC<GenerateModalProps> = ({ onClose, onGenerate, isGenerating, error }) => {
  const [prompt, setPrompt] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt && !isGenerating) {
      await onGenerate(prompt);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
      <div className="bg-dark-card rounded-lg shadow-2xl p-6 md:p-8 w-full max-w-md relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-dark-subtle hover:text-white transition disabled:opacity-50" disabled={isGenerating}>
          <Icon name="close" className="h-6 w-6" />
        </button>
        <h2 className="text-2xl font-bold mb-4 text-white">Generate with AI</h2>
        <p className="text-dark-subtle mb-4">Describe the wallpaper you want to create. Be as creative as you like!</p>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., A neon cityscape at night in a cyberpunk style, raining"
              rows={3}
              className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary"
              disabled={isGenerating}
            />
          </div>
          {error && <p className="text-red-400 text-sm mb-4">{error}</p>}
          <button
            type="submit"
            disabled={!prompt || isGenerating}
            className="w-full flex justify-center items-center bg-brand-primary hover:bg-brand-secondary text-white font-bold py-3 px-4 rounded-md transition disabled:bg-slate-600 disabled:cursor-not-allowed"
          >
            {isGenerating ? <Spinner /> : <><Icon name="sparkles" className="h-5 w-5 mr-2" /> Generate</>}
          </button>
        </form>
      </div>
    </div>
  );
};
