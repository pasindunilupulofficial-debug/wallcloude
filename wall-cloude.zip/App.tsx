
import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SearchBar } from './components/SearchBar';
import { WallpaperGrid } from './components/WallpaperGrid';
import { UploadModal } from './components/UploadModal';
import { GenerateModal } from './components/GenerateModal';
import { generateWallpaper } from './services/geminiService';
import { Wallpaper } from './types';

// Initial placeholder wallpapers
const INITIAL_WALLPAPERS: Wallpaper[] = Array.from({ length: 20 }, (_, i) => ({
  id: `picsum-${i}`,
  url: `https://picsum.photos/seed/${i + 1}/800/1200`,
  author: 'Lorem Picsum',
  likes: Math.floor(Math.random() * 5000),
}));

const App: React.FC = () => {
  const [wallpapers, setWallpapers] = useState<Wallpaper[]>(INITIAL_WALLPAPERS);
  const [searchTerm, setSearchTerm] = useState('');
  const [isUploadModalOpen, setUploadModalOpen] = useState(false);
  const [isGenerateModalOpen, setGenerateModalOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const filteredWallpapers = useMemo(() => {
    if (!searchTerm) return wallpapers;
    // Simple search on author for demonstration
    return wallpapers.filter(w =>
      w.author.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [wallpapers, searchTerm]);

  const handleLike = (id: string) => {
    setWallpapers(prev =>
      prev.map(w => (w.id === id ? { ...w, likes: w.likes + 1 } : w))
    );
  };

  const handleUpload = (file: File, author: string) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const newWallpaper: Wallpaper = {
        id: `upload-${new Date().getTime()}`,
        url: reader.result as string,
        author: author || 'Community Upload',
        likes: 0,
      };
      setWallpapers(prev => [newWallpaper, ...prev]);
      setUploadModalOpen(false);
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async (prompt: string) => {
    setIsGenerating(true);
    setError(null);
    try {
      const imageUrl = await generateWallpaper(prompt);
      const newWallpaper: Wallpaper = {
        id: `ai-${new Date().getTime()}`,
        url: imageUrl,
        author: 'AI Generated',
        likes: 0,
      };
      setWallpapers(prev => [newWallpaper, ...prev]);
      setGenerateModalOpen(false);
    } catch (err) {
        if (err instanceof Error) {
            setError(err.message);
        } else {
            setError('An unknown error occurred during image generation.');
        }
    } finally {
      setIsGenerating(false);
    }
  };


  return (
    <div className="min-h-screen flex flex-col bg-dark-bg">
      <Header
        onUploadClick={() => setUploadModalOpen(true)}
        onGenerateClick={() => setGenerateModalOpen(true)}
      />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-center text-white mb-2">Discover Your Next Wallpaper</h1>
          <p className="text-center text-dark-subtle text-lg">High-quality images for your desktop and mobile devices.</p>
        </div>
        <SearchBar value={searchTerm} onChange={setSearchTerm} />
        <WallpaperGrid
          wallpapers={filteredWallpapers}
          onLike={handleLike}
        />
      </main>
      <Footer />
      {isUploadModalOpen && (
        <UploadModal
          onClose={() => setUploadModalOpen(false)}
          onUpload={handleUpload}
        />
      )}
      {isGenerateModalOpen && (
        <GenerateModal
          onClose={() => { setGenerateModalOpen(false); setError(null); }}
          onGenerate={handleGenerate}
          isGenerating={isGenerating}
          error={error}
        />
      )}
    </div>
  );
};

export default App;
