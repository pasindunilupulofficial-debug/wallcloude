
export interface Wallpaper {
  id: string;
  url: string;
  author: string;
  likes: number;
}
